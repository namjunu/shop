package com.teamp.jang.kiosk;

public class KioskMain {
	public static final int SCREEN_WIDTH = 1280;
	public static final int SCREEN_HEIGHT = 720;
//	public static 는 모든 프로젝트 내부에서 공유할 수 있는 변수
//	final은 한 번 선언되면 절대로 바뀌지 않음
//	int는 정수 SCREEN_WIDTH는 가로화면 SCREEN_HEIGHT는 세로화면 크기
//	상수 한 번 선언되면 바뀌지 않는 상수는 대문자를 통해서 정의한다.

	
}
