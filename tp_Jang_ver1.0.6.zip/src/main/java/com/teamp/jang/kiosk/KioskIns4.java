package com.teamp.jang.kiosk;

import java.awt.Graphics;
import java.awt.Graphics2D;

public class KioskIns4 extends KioskIns3 {
	// 오른쪽에 선택한 것들 추가
	
	
	@Override
	public void KioskGUI() {
		super.KioskGUI();
		
	}
	
	@Override
	public void paint(Graphics g) {
		super.paint(g);
	}
	
	@Override
	public void screenDraw(Graphics2D g) {
		super.screenDraw(g);
	}
	
}
