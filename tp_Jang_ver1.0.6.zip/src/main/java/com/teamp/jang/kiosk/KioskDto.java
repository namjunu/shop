package com.teamp.jang.kiosk;

public class KioskDto {
	
}
